/*
Developer: Ryan Hatch
Date of development: 2024/24/02
Date of last modification: 2024/24/10
*/

const express = require('express');
const router = express.Router();
const travelController = require('../controllers/travel'); // Import the travel controller

// Define your routes here
router.get('/', travelController.travel); // Use the travel function from the travel controller

module.exports = router;

//* Module 02 - old version
// const express = require('express');
// const router = express.Router();


// // Define your routes here
// router.get('/', Controller.travel);
// // router.get('/', (req, res) => {
// //     res.send('Travel page');
// // });

// module.exports = router;

// // const express = require('express');
// // const travlrController = require('../controllers/travel');

// // const router = express.Router();

// // // GET travel page
// // router.get('/', travlrController.travel);

// // module.exports = router;
// //

//* Module 01
// // const express = require('express');
// // const router = express.Router();
// // const travlrController = require('../controllers/travel');

// // // GET travel page
// // router.get('/', travlrController.travel);

// // module.exports = router;