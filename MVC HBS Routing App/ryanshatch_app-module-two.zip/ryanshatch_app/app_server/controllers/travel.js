
/*
Developer: Ryan Hatch
Date of development: 2024/24/02
Date of last modification: 2024/24/10
Description: Main entry point for the application. This file is used to set up the Express application and configure the routes and middleware that the application will use.
*/

// const fs = require('fs');
// const path = require('path');

// module.exports.travel = (req, res) => {
//     // Resolve the path to the trips.json file
//     const tripsFilePath = path.join(__dirname, '../../data/trips.json');
//     let trips = [];

//     try {
//         // Read the trips.json file and parse its content
//         const fileContent = fs.readFileSync(tripsFilePath, 'utf8');
//         trips = JSON.parse(fileContent);
//     } catch (err) {
//         // Log any errors and set trips to an empty array
//         console.error('Error reading or parsing trips.json:', err.message);
//     }

//     // Render the travel view with dynamic trips data
//     res.render('travel', {
//         title: 'Travel',
//         trips: trips
//     });
// };

// Version from 02

/* GET 'travel' page */

const travel = (req, res) => {
    res.render('travel', { title: 'Travlr Getaways' });
};

module.exports = {
    travel
};